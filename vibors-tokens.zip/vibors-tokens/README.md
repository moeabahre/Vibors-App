# Vibors Design Tokens

> Single source of truth for all design decisions — Web, iOS, and Android.
> Managed in Figma → synced to GitHub → auto-built for every platform.

---

## How It Works

```
Figma Variables
      │
      ▼ (Tokens Studio plugin syncs on every change)
  tokens/*.json  ◄──── This repo
      │
      ▼ (GitHub Actions runs on every push to tokens/)
  style-dictionary build
      │
      ├── build/web/          ← CSS Variables + JS/TS + Tailwind
      ├── build/ios/          ← Swift files
      └── build/android/      ← XML resources + Kotlin
```

---

## Token Collections

| # | Collection | Modes | Count | Purpose |
|---|-----------|-------|-------|---------|
| 01 | Primitives | — | 98 | Raw color scales, base sizes |
| 02 | Semantic | Light / Dark | 84 | Meaningful color assignments |
| 03 | Components | Light / Dark | 102 | Component-specific tokens |
| 03 | Spacing | xs / sm / md / lg / xl | 43 | Responsive spacing scale |
| 04 | Typography | xs / sm / md / lg / xl | 69 | Responsive type system |
| 05 | Platform | iOS / Android / Web | 27 | Platform-specific overrides |
| 06 | Radius | iOS / Android / Web | 24 | Corner radius per platform |
| 07 | Grid | Mobile / Tablet / Desktop / Wide | 17 | Grid configuration |
| 08 | Layout | — | 19 | Layout constants |
| 09 | Stroke | — | 6 | Border widths |
| 10 | Opacity | — | 10 | Opacity scale |
| 11 | Motion | — | 22 | Duration + easing |

**Total: 521 tokens**

---

## Web (React)

### Installation

```bash
# Copy the build output into your project
cp -r build/web/ src/styles/tokens/

# Or import directly if this is a private npm package
npm install @vibors/design-tokens
```

### CSS Variables

```css
/* In your global CSS */
@import '@vibors/design-tokens/build/web/tokens.css';

/* Dark mode */
@import '@vibors/design-tokens/build/web/tokens.dark.css';
```

```css
/* Usage */
.button-primary {
  background-color: var(--vbr-button-primary-bg);
  color: var(--vbr-button-primary-text);
  padding: var(--vbr-component-padding-md);
  border-radius: var(--vbr-component-button);
}
```

### JavaScript / TypeScript

```typescript
import tokens from '@vibors/design-tokens/build/web/tokens.js';

// Fully typed
const primaryColor = tokens.button.primary.bg;  // '#4E00FF'
const gap = tokens.component.gap.md;             // '16px'
```

### Tailwind CSS

```javascript
// tailwind.config.js
const viborsTokens = require('@vibors/design-tokens/build/web/tailwind.config.js');

module.exports = {
  presets: [viborsTokens],
  content: ['./src/**/*.{tsx,ts,jsx,js}'],
};
```

```tsx
// Usage in React
<button className="bg-button-primary-bg text-button-primary-text rounded-component-button px-component-padding-md">
  View Profile
</button>
```

---

## iOS (Swift / SwiftUI)

### Installation

Copy these files into your Xcode project:
```
ViborsTokens+Colors.swift
ViborsTokens+Spacing.swift
ViborsTokens+Typography.swift
ViborsTokens+Radius.swift
ViborsTokens+Motion.swift
```

### Usage

```swift
import SwiftUI

// Colors
struct ProfileCard: View {
  var body: some View {
    VStack(spacing: ViborsSpacing.componentGapMd) {
      Text("Sarah Al-Hassan")
        .font(.system(size: ViborsTypography.headingMdSize))
        .foregroundColor(Color(ViborsColors.textPrimary))

      Button("View Profile") {}
        .background(Color(ViborsColors.buttonPrimaryBg))
        .foregroundColor(Color(ViborsColors.buttonPrimaryText))
        .cornerRadius(ViborsRadius.componentButton)
        .padding(.horizontal, ViborsSpacing.componentPaddingMd)
        .padding(.vertical, ViborsSpacing.componentPaddingSm)
    }
    .padding(ViborsSpacing.cardPadding)
    .background(Color(ViborsColors.cardBg))
    .cornerRadius(ViborsRadius.componentCard)
  }
}

// Animations
withAnimation(
  .easeInOut(duration: ViborsMotion.durationNormal)
) {
  isExpanded.toggle()
}
```

---

## Android (Kotlin / Compose + XML)

### Installation

**XML Layout:**
Copy to `app/src/main/res/values/`:
```
vibors_colors.xml
vibors_dimens.xml
vibors_strings.xml
```

**Compose:**
Copy to your theme package:
```
ViborsTokens.kt
```

### Usage — Jetpack Compose

```kotlin
import com.vibors.design.tokens.ViborsTokens

// Colors
Text(
  text = "Sarah Al-Hassan",
  color = ViborsTokens.textPrimary,
  fontSize = ViborsTokens.headingMdSize.sp
)

// Spacing
Card(
  modifier = Modifier.padding(ViborsTokens.cardPadding.dp),
  shape = RoundedCornerShape(ViborsTokens.componentCard.dp)
) {
  Column(
    verticalArrangement = Arrangement.spacedBy(ViborsTokens.componentGapMd.dp)
  ) { ... }
}

// Animation
val transition = tween<Float>(
  durationMillis = ViborsTokens.durationNormal.toInt()
)
```

### Usage — XML Layout

```xml
<TextView
  android:textColor="@color/text_primary"
  android:textSize="@dimen/heading_md_size"
  android:padding="@dimen/card_padding" />

<Button
  android:backgroundTint="@color/button_primary_bg"
  android:textColor="@color/button_primary_text" />
```

---

## Updating Tokens

Tokens are managed **only in Figma**. Never edit the JSON files directly.

### Workflow
1. Designer changes a token in Figma
2. Tokens Studio plugin syncs → creates a PR to this repo
3. GitHub Actions validates + builds automatically
4. PR is reviewed and merged to `main`
5. New release is created with updated build artifacts
6. Developers update their project files from the release

### Manual Build (for testing)

```bash
git clone https://github.com/vibors/design-tokens.git
cd design-tokens
npm install

# Build all platforms
npm run build

# Build specific platform
npm run build:web
npm run build:ios
npm run build:android

# Generate Tailwind config
npm run build:tailwind
```

---

## Token Naming Convention

```
{collection}/{group}/{variant}

Examples:
  color/brand/primary          → brand purple #4E00FF
  spacing/component/gap-md     → 16px gap
  typography/heading/lg/size   → 28px
  radius/component/card        → 12px
  motion/duration/normal       → 200ms
```

---

## Themes

| Theme ID | Description |
|----------|-------------|
| `light-web` | Light mode, Web platform, Desktop grid |
| `dark-web` | Dark mode, Web platform, Desktop grid |
| `light-ios` | Light mode, iOS platform, Mobile grid |
| `dark-ios` | Dark mode, iOS platform, Mobile grid |
| `light-android` | Light mode, Android platform, Mobile grid |
| `dark-android` | Dark mode, Android platform, Mobile grid |

---

## Questions?

Contact the design team or open an issue in this repo.
